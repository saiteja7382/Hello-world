##Hello World sample project

This project is helping user to understand output and input in java using java.util.Scanner class